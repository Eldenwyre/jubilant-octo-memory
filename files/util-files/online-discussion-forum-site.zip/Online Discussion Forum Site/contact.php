<?php  require("header.php"); ?>
<script type="text/javascript">
	document.getElementById("acontact").className="active";
</script>


	<h1>Contact Us</h1>
    <table>


    <tr><td rowspan="4"><img src="ups/1.jpg" style='height:100px; width:100px';></td><td>Name</td><td>:</td><td>John Smith</td></tr>
    <tr><td rowspan="1">Contact No</td><td>:</td><td>xxxxxxxxxx</td></tr>
    <tr><td rowspan="1">E-Mail Add</td><td>:</td><td>johsmith@gmail.com</td></tr>
   <tr><td rowspan="1">Website</td><td>:</td><td><a href="https://sourcecodester.com">www.google.com</a></td></tr>
    </table>

<?php require("footer.php"); ?>
